# Initial code for crypto rewards comparison

def main():
    print("Crypto rewards comparison for Turkey")

if __name__ == "__main__":
    main()
